const $ = (selector, parent = document) => parent.querySelector(selector);
const $$ = (selector, parent = document) => [...parent.querySelectorAll(selector)];
const motion = matchMedia('(prefers-reduced-motion: reduce)');
const preciseHover = matchMedia('(hover: hover) and (pointer: fine)');
const categoryGrid = $('#categories');
const home = $('#home');
const collection = $('#collection');
const search = $('#search');
const searchInput = $('#recipe-search');
const detail = $('#recipe');
const editor = $('#editor');
const boxEditor = $('#box-editor');
const announcement = $('#announcement');
const personal = new Map();
const photoUrls = new WeakMap();
const positions = new Map();
const servingChoices = new Map();
let route = '';
let flightLayer;
let cancelCoverFlight;
let opening = false;
let storage;

const boxColors = [
  ['peach', 'Персиковый'], ['green', 'Фисташковый'], ['lilac', 'Сиреневый'],
  ['sky', 'Голубой'], ['teal', 'Мятный'], ['honey', 'Медовый'],
];
const boxIcons = [['♡', 'Сердце'], ['✦', 'Звёздочка'], ['✿', 'Цветок'], ['☀', 'Солнце'], ['♨', 'Горячее блюдо']];

const escapeHtml = value => String(value).replace(/[&<>"']/g, char => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
})[char]);
const findCategory = id => categories.find(category => category.id === id);
const findRecipe = id => personal.get(id) ?? builtInRecipes.find(item => item.id === id);
const getRecipes = category => [...builtInRecipes, ...personal.values()].filter(item => item.category === category);

function recipeCount(count) {
  if (!count) return 'Пока пусто';
  const last = count % 10;
  const word = count % 100 >= 11 && count % 100 <= 14 ? 'рецептов' : last === 1 ? 'рецепт' : last >= 2 && last <= 4 ? 'рецепта' : 'рецептов';
  return `${count} ${word}`;
}

function photoUrl(photo) {
  if (typeof photo === 'string') return photo;
  if (!photoUrls.has(photo)) photoUrls.set(photo, URL.createObjectURL(photo));
  return photoUrls.get(photo);
}

function gift(category, open = false, items = []) {
  const [pattern, shape] = boxLooks[category.id] ?? [category.pattern || 'plain', 'square'];
  return `<span class="gift wrap-${pattern} shape-${shape} ${open ? 'is-open' : ''}" aria-hidden="true">
    <span class="spark">✧</span><span class="spark">✦</span>
    ${items.slice(0, 2).map(item => `<span class="gift-peek"><img src="${escapeHtml(photoUrl(item.photos[0]))}" alt=""></span>`).join('')}
    <span class="gift-mouth"></span><span class="gift-body"><span class="gift-label">${category.icon}</span></span>
    <span class="gift-lid"><span class="ribbon-knot"></span></span>
  </span>`;
}

function renderHome() {
  categoryGrid.innerHTML = categories.map(category => {
    const items = getRecipes(category.id);
    return `
    <button class="category ${category.style}" type="button" data-category="${category.id}">
      ${gift(category, false, items)}<span class="shelf" aria-hidden="true"></span><span class="box-caption"><strong>${escapeHtml(category.name)}</strong>
      ${category.note ? `<span class="category-note">${escapeHtml(category.note)}</span>` : ''}
      <span class="box-count">${recipeCount(items.length)}</span></span>
    </button>`;
  }).join('');
}

function tag(item) {
  if (!item.minutes) return 'Твой рецепт';
  const hours = Math.floor(item.minutes / 60);
  const minutes = item.minutes % 60;
  return hours ? `${hours} ч${minutes ? ` ${minutes} мин` : ''}` : `${minutes} мин`;
}

function caloriesPerServing(item) {
  return item.calories ?? dishNotes[item.id]?.[1];
}

function recipeCard(item, showCategory = false, highlight = null, preview = false, lazy = false) {
  const titleId = `${showCategory ? 'search-title' : 'title'}-${item.id}`;
  const category = findCategory(item.category);
  const element = preview ? 'div' : 'button';
  const friendly = friendlyTitles[item.id];
  const ingredient = highlight && item.ingredients.find(([name]) => name.match(highlight))?.[0];
  return `<div class="tilt-shell ${category.style}"><${element} class="recipe-card" ${preview ? '' : `type="button" data-go="recipe/${item.id}" aria-labelledby="${titleId}"`}>
    <span class="card-photo">
      ${item.photos.length ? `<img src="${escapeHtml(photoUrl(item.photos[0]))}" alt="" width="510" height="330"${lazy ? ' loading="lazy"' : ''}>`
        : '<span class="card-photo-placeholder">Фото блюда</span>'}
      ${item.photos.length > 1 ? `<span class="card-thumbnails">${item.photos.slice(1, 4).map(photo => `<img src="${escapeHtml(photoUrl(photo))}" alt="" width="42" height="35">`).join('')}</span>` : ''}
    </span>
    <span class="card-content">
      <span class="card-meta"><span class="tag ${item.minutes ? '' : 'personal-sticker'}">${item.minutes ? '<i class="tiny-icon clock" aria-hidden="true"></i>' : ''}${tag(item)}</span>
        <span class="tag servings-tag" aria-label="Порций: ${item.servings || 1}"><i class="tiny-icon plate" aria-hidden="true"></i>${item.servings || 1}</span>
        ${caloriesPerServing(item) != null ? `<span class="tag calorie-tag">≈ ${caloriesPerServing(item)} ккал / порция</span>` : ''}
      </span>
      ${friendly ? `<span class="dish-kicker">${markedText(item.title, highlight)}</span>` : ''}
      <strong id="${titleId}">${markedText(friendly || item.title, highlight)}</strong>
      <span class="summary">${markedText(item.short, highlight)}</span>
      ${ingredient ? `<span class="search-match">В ингредиентах есть ${markedText(ingredient, highlight)}</span>` : ''}
      ${showCategory ? `<span class="card-category">${markedText(category.name, highlight)}</span>` : ''}
    </span>
  </${element}></div>`;
}

function searchWords(text) {
  return text.toLowerCase().replaceAll('ё', 'е').match(/[\p{L}\p{N}]+/gu) ?? [];
}

function renderSearch() {
  const words = searchWords(searchInput.value);
  const highlight = words.length ? new RegExp(words.sort((a, b) => b.length - a.length)
    .map(word => word.replaceAll('е', '[её]')).join('|'), 'giu') : null;
  const matches = [...builtInRecipes, ...personal.values()].filter(item => {
    const text = [item.title, friendlyTitles[item.id], item.short, item.cuisine, findCategory(item.category).name, ...item.ingredients.map(([name]) => name)]
      .join(' ').toLowerCase().replaceAll('ё', 'е');
    return words.every(word => text.includes(word));
  });
  $('#clear-search').hidden = !searchInput.value;
  $('#search-status').textContent = matches.length
    ? `Найдено: ${recipeCount(matches.length)}`
    : 'Ничего не нашли. Попробуй одно слово, например «сыр».';
  $('#search-layout').innerHTML = catalogToggle();
  $('#search-results').innerHTML = matches.map((item, index) => recipeCard(item, true, highlight, false, index >= 6)).join('');
}

function renderCollection(category) {
  const items = getRecipes(category.id);
  collection.innerHTML = `
    <div class="subpage">
      <div class="button-row">
        <button class="outline back" type="button" data-go="home">К коробочкам</button>
        <a class="outline" href="#search">Найти рецепт</a>
        ${items.length ? catalogToggle() : ''}
      </div>
      <div class="collection-banner ${category.style}">
        <div><h1 tabindex="-1">${escapeHtml(category.name)}</h1><p>${escapeHtml(category.note || recipeCount(items.length))}</p></div>
        ${gift(category, true)}
      </div>
      ${items.length ? `<div class="recipe-grid">${items.map((item, index) => recipeCard(item, false, null, false, index >= 6)).join('')}</div>` : `<div class="empty-box ${category.style}"><div class="sheet empty-recipe"><div class="empty-recipe-art" aria-hidden="true"></div><h2>Здесь пока пусто</h2>
        <button class="primary create" type="button"><span aria-hidden="true">＋</span> Добавить первый рецепт</button></div></div>`}
    </div>`;
}

function renderDetail(item) {
  const hasPoster = illustratedRecipeIds.has(item.id);
  const baseServings = item.servings || 1;
  const servings = servingChoices.get(item.id) ?? baseServings;
  const overview = item.overview || dishNotes[item.id]?.[0];
  const calories = caloriesPerServing(item);
  const backToSearch = history.state?.backToSearch;
  const ingredientNames = item.ingredients.map(([name]) => name.toLowerCase());
  const glossary = ingredientGlossary.filter(([term]) => ingredientNames.some(name =>
    name.split(/[^а-яё]+/).some(word => word.startsWith(term))));
  detail.innerHTML = `
    <article class="subpage">
      <div class="button-row">
        <button class="outline back" type="button" data-go="${backToSearch ? 'search' : `box/${item.category}`}">${backToSearch ? 'К результатам поиска' : 'К карточкам'}</button>
        ${personal.has(item.id) ? `<button class="quiet" type="button" data-go="edit/${item.id}">Редактировать рецепт</button>` : ''}
        ${hasPoster ? '' : `<button class="outline recipe-jump" type="button" data-jump="recipe-ingredients">К ингредиентам</button>
        <button class="outline recipe-jump" type="button" data-jump="recipe-steps">К шагам</button>
        <button class="primary recipe-jump" type="button" data-cook-open>Режим готовки</button>`}
      </div>
      <div class="recipe-paper${hasPoster ? ' recipe-paper--poster' : ''}">
      ${hasPoster ? `<div class="recipe-poster">
        <h1 class="visually-hidden" tabindex="-1">${escapeHtml(item.title)}</h1>
        <a href="assets/posters/${item.id}.webp" target="_blank" rel="noopener" aria-label="Открыть карточку в полном размере">
          <img src="assets/posters/${item.id}.webp" alt="Иллюстрированная карточка «${escapeHtml(item.title)}»">
        </a>
      </div>` : `<header class="recipe-header">
        <h1 class="page-title" tabindex="-1">${escapeHtml(item.title)}</h1>
        <div class="button-row"><span class="tag">${escapeHtml(findCategory(item.category).name)}</span>
        ${item.cuisine ? `<span class="tag">${escapeHtml(item.cuisine)}</span>` : ''}
        ${item.minutes ? `<span class="tag">${tag(item)}</span>` : ''}</div>
        <p class="recipe-deck">${escapeHtml(item.short)}</p>
      </header>
      <div class="recipe-intro">
        <div class="gallery">${item.photos.map((photo, index) => `<img src="${escapeHtml(photoUrl(photo))}" alt="${escapeHtml(item.title)}${item.photos.length > 1 ? ` — фото ${index + 1}` : ''}">`).join('')}</div>`}
        <section class="recipe-pantry"><h2 id="recipe-ingredients" tabindex="-1">Ингредиенты</h2>
          <div class="portion-controls">
            <label for="servings">Порции</label>
            <div class="portion-stepper">
              <button class="remove" type="button" data-portion="-1" aria-label="Уменьшить количество порций">−</button>
              <input id="servings" type="number" inputmode="numeric" min="1" max="100" step="1" value="${servings}">
              <button class="remove" type="button" data-portion="1" aria-label="Увеличить количество порций">+</button>
            </div>
          </div>
          ${calories != null ? '<p class="portion-total muted" hidden></p>' : ''}
          <p class="ingredient-check-hint muted">Отмечай то, что уже подготовил.</p>
          <div class="prep-progress"><output aria-live="polite">Подготовлено 0 из ${item.ingredients.length}</output>
            <progress aria-label="Подготовленные ингредиенты" value="0" max="${item.ingredients.length}"></progress></div>
          <ul class="ingredients">${item.ingredients.map(([name, amount]) => {
            const parts = searchWords(name);
            const term = glossary.find(([prefix]) => parts.some(part => part.startsWith(prefix)));
            return `<li><label class="ingredient-option"><input type="checkbox"><span>${escapeHtml(name)}</span><strong>${amountMarkup(amount)}</strong></label>
              ${term ? `<details class="inline-ingredient"><summary>Что такое ${term[1].toLowerCase()}?</summary><p>${term[2]}</p></details>` : ''}</li>`;
          }).join('')}</ul>
          ${glossary.length ? `<details class="ingredient-glossary"><summary>Что это за ингредиенты?</summary>
            <dl>${glossary.map(([, term, definition]) => `<div><dt>${term}</dt><dd>${definition}</dd></div>`).join('')}</dl>
          </details>` : ''}
          ${hasPoster ? '<button class="outline recipe-cook-button" type="button" data-cook-open>Режим готовки</button>' : ''}
        </section>
      ${hasPoster ? '' : `</div>
      <section class="recipe-method">
        <h2 id="recipe-steps" tabindex="-1">Приготовление</h2>
        <ol class="steps">${item.steps.map(step => `<li>${stepMarkup(step)}</li>`).join('')}</ol>
      </section>
      <section class="dish-facts">
        <div>
          <h2>Что это за блюдо?</h2>
          <p class="description">${escapeHtml(overview || item.description)}</p>
          ${overview && overview !== item.description ? `<p class="description">${escapeHtml(item.description)}</p>` : ''}
        </div>
        <div class="nutrition">
          <h2>Калорийность</h2>
          ${calories != null ? `<p><strong>≈ ${calories} ккал</strong> на 1 порцию</p>` : '<p>Пока не указана.</p>'}
          <details><summary>Что значит «ккал»?</summary><p>Килокалории показывают, сколько энергии даёт еда. Число примерное и зависит от продуктов и размера порции.</p></details>
        </div>
      </section>`}
      ${recipeCredit(item, !hasPoster)}
      </div>
      ${hasPoster ? '' : `<nav class="mobile-cook-nav" aria-label="Разделы рецепта">
        <button class="outline" type="button" data-jump="recipe-ingredients">Продукты</button>
        <button class="outline" type="button" data-jump="recipe-steps">Шаги</button>
      </nav>`}
      <dialog class="cook-mode" aria-labelledby="cook-mode-title">
        <form method="dialog"><button class="outline" type="submit" autofocus>Закрыть</button></form>
        <h2 id="cook-mode-title">${escapeHtml(item.title)}</h2>
        <div aria-live="polite"><p class="cook-counter"></p><p class="cook-step"></p></div>
        <div class="button-row cook-actions">
          <button class="outline" type="button" data-cook-prev>Назад</button>
          <button class="primary" type="button" data-cook-next>Дальше</button>
        </div>
      </dialog>
    </article>`;
  const servingInput = $('#servings', detail);
  const amounts = $$('.ingredients strong', detail);
  const buttons = $$('[data-portion]', detail);
  const total = $('.portion-total', detail);
  setupCooking(item, detail);
  function updateAmounts(count) {
    servingChoices.set(item.id, count);
    amounts.forEach((amount, index) => {
      amount.innerHTML = amountMarkup(scaleAmount(item.ingredients[index][1], count / baseServings));
    });
    buttons[0].disabled = count === 1;
    buttons[1].disabled = count === 100;
    if (total) {
      total.hidden = count === 1;
      total.textContent = `На выбранное количество порций всего ≈ ${(calories * count).toLocaleString('ru-RU')} ккал.`;
    }
  }
  updateAmounts(servings);
  servingInput.addEventListener('input', () => {
    if (servingInput.validity.valid && servingInput.value) updateAmounts(servingInput.valueAsNumber);
  });
  servingInput.addEventListener('change', () => {
    if (!servingInput.validity.valid || !servingInput.value) {
      servingInput.value = servingChoices.get(item.id);
    }
  });
  for (const button of buttons) button.addEventListener('click', () => {
    const count = servingChoices.get(item.id) + Number(button.dataset.portion);
    servingInput.value = count;
    updateAmounts(count);
    announcement.textContent = `Количество порций — ${count}.`;
  });
}

function recipeCredit(item, includePhoto) {
  if (!item.source) return '';
  if (!item.worldCredit) {
    return `<p class="recipe-source">Рецепт USDA MyPlate Kitchen${includePhoto ? ', фото из архива ' : ', архив '}<a href="${escapeHtml(item.source)}" target="_blank" rel="noopener noreferrer">MyPlate.food</a>.${item.methodSource ? ` <a href="${escapeHtml(item.methodSource)}" target="_blank" rel="noopener noreferrer">Источник шагов</a>.` : ''}</p>`;
  }
  const { version, photoUrl, photoAuthor, photoLicense, photoLicenseUrl } = item.worldCredit;
  return `<div class="recipe-source">
    <p>Рецепт из <a href="${escapeHtml(item.source)}" target="_blank" rel="noopener noreferrer">UniTools World Recipes</a>, версия ${escapeHtml(version)}. Адаптировано для каталога. <a href="https://creativecommons.org/licenses/by-sa/4.0/" target="_blank" rel="noopener noreferrer">CC BY-SA 4.0</a>.</p>
    ${includePhoto ? `<p>Фото в уменьшенном размере. Автор — <a href="${escapeHtml(photoUrl)}" target="_blank" rel="noopener noreferrer">${escapeHtml(photoAuthor)}</a>. <a href="${escapeHtml(photoLicenseUrl)}" target="_blank" rel="noopener noreferrer">${escapeHtml(photoLicense)}</a>.</p>` : ''}
  </div>`;
}

const fractions = { '¼': 1 / 4, '½': 1 / 2, '¾': 3 / 4, '⅓': 1 / 3, '⅔': 2 / 3,
  '⅛': 1 / 8, '⅜': 3 / 8, '⅝': 5 / 8, '⅞': 7 / 8, '⅕': 1 / 5, '⅖': 2 / 5,
  '⅗': 3 / 5, '⅘': 4 / 5, '⅙': 1 / 6, '⅚': 5 / 6 };
const fractionCharacters = Object.keys(fractions).join('');
const quantity = String.raw`(?:\d+\s+\d+\s*/\s*\d+|\d+\s*/\s*\d+|\d*\s*[${fractionCharacters}]|\d{1,3}(?:[ \u00a0\u202f]\d{3})+(?:[.,]\d+)?|\d+(?:[.,]\d+)?)(?![\d/])`;
const quantityPrefix = new RegExp(`^(${quantity})(?:\\s*[-–—]\\s*(${quantity}))?(.*)$`);
const formatAmount = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 3 });

function numericAmount(text) {
  const unicodeFraction = fractions[text.at(-1)];
  if (unicodeFraction) return Number(text.slice(0, -1).trim()) + unicodeFraction;
  const division = text.match(/^(?:(\d+)\s+)?(\d+)\s*\/\s*(\d+)$/);
  if (division) return Number(division[1] || 0) + Number(division[2]) / Number(division[3]);
  return Number(text.replace(/\s/g, '').replace(',', '.'));
}

function scaleAmount(amount, scale) {
  if (scale === 1) return amount;
  const match = amount.match(quantityPrefix);
  if (!match) return amount;
  const [, start, end, unit] = match;
  const low = numericAmount(start) * scale;
  const high = end ? numericAmount(end) * scale : low;
  if (!Number.isFinite(low) || !Number.isFinite(high)) return amount;
  const scaled = end ? `${formatAmount.format(low)}–${formatAmount.format(high)}` : formatAmount.format(low);
  return scaled + unit;
}

function remember() {
  positions.set(route, { top: window.scrollY, focus: document.activeElement?.dataset.go });
}

function go(next, { origin, restore = false, replace = false, visual } = {}) {
  remember();
  if (route !== next || location.hash !== '#' + next) {
    const fromSearch = route === 'search' && next.startsWith('recipe/');
    const editingFromSearch = history.state?.backToSearch &&
      (next.startsWith('edit/') || (route.startsWith('edit/') && next.startsWith('recipe/')));
    history[replace ? 'replaceState' : 'pushState'](fromSearch || editingFromSearch ? { backToSearch: true } : null, '', '#' + next);
  }
  show(next, { origin, restore, visual });
}

function show(next, { origin, restore = false, initial = false, visual } = {}) {
  flightLayer?.remove();
  collection.removeAttribute('aria-busy');
  $('.cook-mode[open]', detail)?.close();
  cancelCoverFlight?.();
  const [page, id] = next.split('/');
  const item = findRecipe(id);
  const category = findCategory(id);
  let view = home;
  let focusSelector = 'h1';
  if (page === 'box' && category) {
    view = collection;
    renderCollection(category);
  } else if (page === 'recipe' && item) {
    view = detail;
    renderDetail(item);
  } else if (page === 'search') {
    view = search;
    renderSearch();
  } else if (page === 'new-box') {
    view = boxEditor;
    renderBoxEditor();
  } else if (page === 'new' || (page === 'edit' && personal.has(id))) {
    view = editor;
    const defaultCategory = next.split('/')[1] || (route.startsWith('box/') ? route.split('/')[1] : '');
    renderEditor(page === 'edit' ? item : null, defaultCategory);
  } else {
    renderHome();
    next = page === 'boxes' ? 'boxes' : 'home';
    if (next === 'boxes') focusSelector = '#boxes-title';
  }

  for (const section of [home, collection, search, detail, editor, boxEditor]) section.hidden = section !== view;
  // Only a clicked gift keeps its opened appearance during the outgoing frame.
  $$('.category .is-open').forEach(box => box.classList.remove('is-open'));
  route = next;
  const previous = restore && positions.get(route);
  const previousButton = previous?.focus && $$('[data-go]', view).find(button => button.dataset.go === previous.focus);
  const focus = previousButton || $(focusSelector, view);
  if (!initial || next === 'boxes') focus.focus({ preventScroll: true });
  if (previous) window.scrollTo(0, previous.top);
  else if (next === 'boxes') $('#boxes').scrollIntoView({ block: 'start' });
  else window.scrollTo(0, 0);
  if (origin && view === collection) launchCards(origin);
  if (visual && view === detail) revealRecipe(visual.cover);
  if (visual && (view === collection || view === search)) settleCard(visual, view);
}

function setupCardTilt() {
  let activeCard;
  let cursor;
  let frame = 0;

  function reset() {
    cancelAnimationFrame(frame);
    frame = 0;
    if (!activeCard) return;
    for (const property of ['--tilt-x', '--tilt-y', '--light-x', '--light-y']) {
      activeCard.style.removeProperty(property);
    }
    activeCard = null;
  }

  document.addEventListener('pointermove', event => {
    const card = !motion.matches && preciseHover.matches && event.pointerType !== 'touch'
      ? event.target.closest('.tilt-shell') : null;
    if (card !== activeCard) reset();
    if (!card) return;
    activeCard = card;
    cursor = { x: event.clientX, y: event.clientY };
    if (frame) return;
    frame = requestAnimationFrame(() => {
      frame = 0;
      const bounds = activeCard.getBoundingClientRect();
      if (!bounds.width || !bounds.height) {
        reset();
        return;
      }
      const horizontal = Math.max(0, Math.min(1, (cursor.x - bounds.left) / bounds.width));
      const vertical = Math.max(0, Math.min(1, (cursor.y - bounds.top) / bounds.height));
      activeCard.style.setProperty('--tilt-x', `${(0.5 - vertical) * 21}deg`);
      activeCard.style.setProperty('--tilt-y', `${(horizontal - 0.5) * 23}deg`);
      activeCard.style.setProperty('--light-x', `${horizontal * 100}%`);
      activeCard.style.setProperty('--light-y', `${vertical * 100}%`);
    });
  }, { passive: true });
  document.documentElement.addEventListener('pointerleave', reset);
  window.addEventListener('scroll', reset, { passive: true });
  window.addEventListener('blur', reset);
  motion.addEventListener('change', reset);
  preciseHover.addEventListener('change', reset);
}

function snapshotCover(image) {
  if (!image?.naturalWidth || motion.matches) return;
  const rect = image.getBoundingClientRect();
  if (inViewport(rect)) return { rect, image: image.cloneNode() };
}

function inViewport(rect) {
  return rect.width > 0 && rect.height > 0
    && rect.bottom > 0 && rect.top < innerHeight && rect.right > 0 && rect.left < innerWidth;
}

function flyCover(source, destination, returning = false) {
  if (!source || !destination?.animate || motion.matches) return false;
  const target = destination.getBoundingClientRect();
  if (!inViewport(target)) return false;
  const { image, rect } = source;
  const layer = document.createElement('div');
  layer.className = 'cover-flight';
  layer.setAttribute('aria-hidden', 'true');
  image.alt = '';
  Object.assign(image.style, { left: `${rect.left}px`, top: `${rect.top}px` });
  layer.append(image);
  document.body.append(layer);
  const start = { width: `${rect.width}px`, height: `${rect.height}px`, borderRadius: returning ? '23px' : '15px' };
  const end = { width: `${target.width}px`, height: `${target.height}px`, borderRadius: returning ? '15px' : '23px' };
  const transform = `translate(${target.left - rect.left}px,${target.top - rect.top}px)`;
  const duration = returning ? 415 : 510;
  const flight = image.animate([
    { ...start, transform: 'translate(0, 0)', offset: 0, easing: 'cubic-bezier(.2,.7,.3,1)' },
    { ...start, transform: `translateY(${returning ? -5 : -12}px) rotate(${returning ? 2 : -3}deg) scale(1.035)`, offset: .18, easing: 'cubic-bezier(.35,0,.2,1)' },
    { ...end, transform, offset: 1, boxShadow: '0 0 0 0 transparent' },
  ], { duration, fill: 'both' });
  const coverReveal = destination.animate([{ opacity: 0 }, { opacity: 0, offset: .9 }, { opacity: 1 }], { duration });
  const scrollTop = window.scrollY;
  const onScroll = () => {
    if (window.scrollY !== scrollTop) cleanup();
  };
  const cleanup = () => {
    layer.remove();
    flight.cancel();
    coverReveal.cancel();
    window.removeEventListener('scroll', onScroll);
    window.removeEventListener('resize', cleanup);
    motion.removeEventListener('change', cleanup);
    if (cancelCoverFlight === cleanup) cancelCoverFlight = null;
  };
  cancelCoverFlight = cleanup;
  window.addEventListener('scroll', onScroll);
  window.addEventListener('resize', cleanup);
  motion.addEventListener('change', cleanup);
  flight.addEventListener('finish', cleanup, { once: true });
  return true;
}

function revealRecipe(cover) {
  const image = $('.gallery img', detail);
  if (motion.matches) {
    $('article', detail).animate?.([{ opacity: .35 }, { opacity: 1 }], { duration: 140 });
    return;
  }
  const coverIsFlying = flyCover(cover, image);
  const sections = [$('.recipe-header', detail), ...$$('.gallery img', detail), ...$$('.recipe-body .sheet', detail)];
  sections.forEach((section, index) => {
    if (section === image && coverIsFlying) return;
    section.animate?.([
      { opacity: 0, transform: 'translateY(15px)' },
      { opacity: 1, transform: 'translateY(0)' },
    ], { duration: 330, delay: Math.min(index * 55, 220), easing: 'ease-out', fill: 'backwards' });
  });
}

function settleCard({ cover, recipeRoute }, view) {
  const card = $$('.recipe-card', view).find(item => item.dataset.go === recipeRoute);
  if (!card) return;
  if (motion.matches) {
    card.animate?.([{ opacity: .55 }, { opacity: 1 }], { duration: 130 });
    return;
  }
  const coverIsFlying = flyCover(cover, $('img', card), true);
  card.animate?.([
    { transform: 'scale(.975)', boxShadow: '0 0 0 3px #edb6c4' },
    { transform: 'scale(1.022)', offset: .45 },
    { transform: 'scale(1)' },
  ], { duration: 275, delay: coverIsFlying ? 415 : 0, easing: 'ease-out' });
}

async function openGift(button) {
  if (opening) return;
  opening = true;
  const box = $('.gift', button);
  // Bring a partly visible box into view before measuring its opening.
  const bounds = box.getBoundingClientRect();
  if (bounds.top < 12 || bounds.bottom > innerHeight - 12) button.scrollIntoView({ block: 'center' });
  box.classList.add('is-open');
  if (!motion.matches) await new Promise(resolve => setTimeout(resolve, 205));
  opening = false;
  if (home.hidden || !box.classList.contains('is-open')) return;
  const mouth = $('.gift-mouth', box).getBoundingClientRect();
  go('box/' + button.dataset.category, { origin: {
    x: mouth.left + mouth.width / 2,
    y: mouth.top + mouth.height / 2,
    box: box.cloneNode(true),
    bounds: box.getBoundingClientRect(),
    style: findCategory(button.dataset.category).style,
    sparks: boxLooks[button.dataset.category]?.[2] ?? '✧✦',
  } });
}

async function closeGift(id) {
  const banner = $('.collection-banner', collection);
  const mouth = $('.gift-mouth', banner);
  const bounds = mouth.getBoundingClientRect();
  const cards = $$('.recipe-card', collection).slice(0, 3);
  const visibleCards = cards.filter(card => !card.classList.contains('in-flight'))
    .map(card => [card, card.getBoundingClientRect()]).filter(([, rect]) => inViewport(rect));
  if (flightLayer?.dataset.closing) return;
  if (!motion.matches && cards[0]?.animate && inViewport(bounds) && visibleCards.length) {
    flightLayer?.remove();
    const layer = document.createElement('div');
    layer.className = `flight-layer ${findCategory(id).style}`;
    layer.dataset.closing = '';
    layer.setAttribute('aria-hidden', 'true');
    document.body.append(layer);
    flightLayer = layer;
    collection.setAttribute('aria-busy', 'true');
    const animations = visibleCards.map(([card, rect], index) => {
      const clone = card.cloneNode(true);
      clone.classList.add('closing-card');
      clone.removeAttribute('aria-labelledby');
      clone.removeAttribute('data-go');
      clone.tabIndex = -1;
      $('[id]', clone).removeAttribute('id');
      Object.assign(clone.style, {
        left: `${rect.left}px`, top: `${rect.top}px`, width: `${rect.width}px`, height: `${rect.height}px`,
      });
      card.classList.add('in-flight');
      layer.append(clone);
      const x = bounds.left + bounds.width / 2 - rect.left - rect.width / 2;
      const y = bounds.top + bounds.height / 2 - rect.top - rect.height / 2;
      return clone.animate([
        { transform: 'none', opacity: 1 },
        { transform: `translate(${x}px,${y - 28 + index * 3}px) rotate(${(index - 1) * 5}deg) scale(.23)`, opacity: 1, offset: .76 },
        { transform: `translate(${x}px,${y}px) scale(.08)`, opacity: 0 },
      ], { duration: 350, delay: index * 19, fill: 'both', easing: 'cubic-bezier(.22,.72,.27,1)' });
    });
    await Promise.allSettled(animations.map(animation => animation.finished));
    if (!layer.isConnected) return;
    $('.gift', banner).classList.remove('is-open');
    await new Promise(resolve => setTimeout(resolve, 125));
    if (!layer.isConnected) return;
  }
  go('boxes');
  $$('[data-category]', home).find(button => button.dataset.category === id)?.focus({ preventScroll: true });
}

function launchCards({ x, y, box, bounds, style, sparks }) {
  const allCards = $$('.recipe-card', collection);
  const cards = allCards.slice(0, 3);
  const waitingCards = allCards.slice(3);
  if (!cards.length) return;
  if (motion.matches || typeof cards[0]?.animate !== 'function') {
    for (const card of allCards) card.animate?.([{ opacity: .2 }, { opacity: 1 }], { duration: 140 });
    return;
  }
  const layer = document.createElement('div');
  layer.className = `flight-layer ${style}`;
  layer.setAttribute('aria-hidden', 'true');
  document.body.append(layer);
  flightLayer = layer;
  for (let index = 0; index < 7; index++) {
    const spark = document.createElement('span');
    spark.className = 'opening-spark';
    spark.textContent = sparks[index % sparks.length];
    if (sparks === '∿') spark.classList.add('steam-spark');
    spark.style.left = `${x}px`;
    spark.style.top = `${y}px`;
    layer.append(spark);
    const horizontal = (index - 3) * 28;
    const vertical = -65 - (3 - Math.abs(index - 3)) * 22;
    spark.animate([
      { transform: 'translate(-50%, -50%) scale(.2)', opacity: 0 },
      { transform: `translate(${horizontal * .7}px, ${vertical}px) rotate(${horizontal / 2}deg) scale(1.15)`, opacity: 1, offset: .42 },
      { transform: `translate(${horizontal}px, ${vertical + 25}px) rotate(${horizontal}deg) scale(.35)`, opacity: 0 },
    ], { duration: 600, delay: index * 14, easing: 'ease-out', fill: 'both' });
  }
  waitingCards.forEach(card => card.classList.add('in-flight'));

  // The opened gift stays in its original screen position during takeoff.
  Object.assign(box.style, { position: 'absolute', left: `${bounds.left}px`, top: `${bounds.top}px`,
    width: `${bounds.width}px`, height: `${bounds.height}px` });
  layer.append(box);
  box.animate([{ opacity: 1, offset: 0 }, { opacity: 1, offset: .4 }, { opacity: 0 }],
    { duration: 490, fill: 'forwards' });

  const grid = $('.recipe-grid', collection);
  const gridTop = grid.getBoundingClientRect().top;
  const firstCardsBottom = cards[Math.min(cards.length, 3) - 1].getBoundingClientRect().bottom;
  // On short screens, land the first rows together before growing them to reading size.
  const landingScale = Math.max(.22, Math.min(1, (innerHeight - gridTop - 12) / (firstCardsBottom - gridTop)));
  const compact = landingScale < 1;
  const duration = compact ? 620 : 735;
  if (compact) grid.style.transform = `scale(${landingScale})`;

  cards.forEach((card, index) => {
    const rect = card.getBoundingClientRect();
    const clone = card.cloneNode(true);
    const width = card.offsetWidth;
    const height = card.offsetHeight;
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    clone.tabIndex = -1;
    clone.removeAttribute('aria-labelledby');
    $('[id]', clone).removeAttribute('id');
    Object.assign(clone.style, { left: `${centerX - width / 2}px`, top: `${centerY - height / 2}px`, width: `${width}px`, height: `${height}px` });
    layer.append(clone);
    card.classList.add('in-flight');
    const startX = x - centerX;
    const startY = y - centerY;
    const lane = (index % 3) - 1;
    const fanScale = compact ? .33 : .43;
    const step = Math.min(112, innerWidth * .19);
    const margin = Math.min(innerWidth / 2 - step, Math.hypot(width, height) * fanScale / 2);
    const fanCenter = Math.max(margin + step, Math.min(innerWidth - margin - step, x));
    const fanX = fanCenter + lane * step;
    const fanY = Math.max(85, Math.min(innerHeight - 110, y - 92 - (1 - Math.abs(lane)) * 32));
    const motionFrames = [
      { transform: `translate(${startX}px,${startY}px) rotate(${lane * 7}deg) scale(.15)`, offset: 0, easing: 'cubic-bezier(.18,.74,.35,1)' },
      { transform: `translate(${fanX - centerX}px,${fanY - centerY}px) rotate(${lane * 20}deg) scale(${fanScale})`, offset: .42, easing: 'cubic-bezier(.36,0,.25,1)' },
      { transform: `translate(0,0) rotate(0deg) scale(${landingScale})`, offset: 1 },
    ];
    const animation = clone.animate(motionFrames, { duration, delay: (index % 3) * 19, fill: 'both' });
    animation.finished.then(() => {
      card.classList.remove('in-flight');
      clone.remove();
    }, () => card.classList.remove('in-flight'));
  });
  const discard = () => {
    layer.remove();
    const stillOpen = layer === flightLayer && grid.isConnected && !collection.hidden;
    allCards.forEach(card => card.classList.remove('in-flight'));
    if (stillOpen && !motion.matches) {
      waitingCards.forEach((card, index) => card.animate(
        [{ opacity: 0 }, { opacity: 1 }], { duration: 180, delay: Math.min(index * 25, 100), fill: 'backwards' }));
    }
    if (compact) {
      if (stillOpen && !motion.matches) {
        grid.animate([{ transform: `scale(${landingScale})` }, { transform: 'scale(1)' }],
          { duration: 160, easing: 'ease-out' });
      }
      grid.style.transform = '';
    }
    if (flightLayer === layer) flightLayer = null;
  };
  setTimeout(discard, duration + 55);
}

function connectStorage() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open('vkusnye-kartochki', 2);
    request.onupgradeneeded = () => {
      for (const store of ['recipes', 'boxes']) {
        if (!request.result.objectStoreNames.contains(store)) request.result.createObjectStore(store, { keyPath: 'id' });
      }
    };
    request.onsuccess = () => {
      const db = request.result;
      db.onversionchange = () => db.close();
      resolve(db);
    };
    request.onerror = () => reject(request.error);
    request.onblocked = () => reject(new Error('Закрой сайт в других вкладках и обнови эту страницу.'));
  });
}

function readRecords(db, store) {
  return new Promise((resolve, reject) => {
    const request = db.transaction(store).objectStore(store).getAll();
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

function saveRecord(db, store, item) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(store, 'readwrite');
    transaction.oncomplete = resolve;
    transaction.onabort = () => reject(transaction.error);
    transaction.objectStore(store).put(item);
  });
}

function renderBoxEditor() {
  boxEditor.innerHTML = `
    <div class="editor-inner subpage">
      <button class="outline back" type="button" data-go="boxes">Отмена</button>
      <h1 tabindex="-1" class="page-title">Создать коробочку</h1>
      <form class="sheet">
        <label>Название коробочки<input name="name" maxlength="45" placeholder="Например, Семейные рецепты" required></label>
        <label>Короткое описание <span class="muted optional">Необязательно</span><input name="note" maxlength="85"></label>
        <div class="box-options">
          <label>Цвет<select name="style">${boxColors.map(([id, title]) => `<option value="${id}">${title}</option>`).join('')}</select></label>
          <label>Значок<select name="icon">${boxIcons.map(([icon, title]) => `<option value="${icon}">${icon} ${title}</option>`).join('')}</select></label>
        </div>
        <label>Узор упаковки<select name="pattern">${wrappingOptions.map(([id, title]) => `<option value="${id}">${title}</option>`).join('')}</select></label>
        <div class="box-preview" aria-hidden="true"></div>
        <p class="notice" role="alert" hidden></p>
        <div class="button-row"><button class="primary" type="submit">Сохранить коробочку</button></div>
      </form>
    </div>`;
  const form = $('form', boxEditor);
  const preview = $('.box-preview', form);
  const notice = $('.notice', form);
  const submit = $('[type=submit]', form);
  function updatePreview() {
    preview.className = `box-preview ${form.elements.style.value}`;
    preview.innerHTML = gift({ icon: form.elements.icon.value, pattern: form.elements.pattern.value });
  }
  form.addEventListener('change', updatePreview);
  updatePreview();
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (submit.disabled) return;
    const name = form.elements.name.value.trim();
    if (!name) {
      notice.textContent = 'Введи название коробочки.';
      notice.hidden = false;
      form.elements.name.focus();
      return;
    }
    const box = {
      id: `box-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`,
      name,
      note: form.elements.note.value.trim(),
      style: form.elements.style.value,
      icon: form.elements.icon.value,
      pattern: form.elements.pattern.value,
    };
    submit.disabled = true;
    notice.hidden = true;
    try {
      if (!storage) throw new Error();
      await saveRecord(storage, 'boxes', box);
      categories.push(box);
      if (boxEditor.contains(form) && !boxEditor.hidden) go('box/' + box.id, { replace: true });
      announcement.textContent = 'Коробочка создана.';
    } catch {
      notice.textContent = 'Не удалось сохранить коробочку. Попробуй снова в обычном окне браузера.';
      notice.hidden = false;
      submit.disabled = false;
    }
  });
}

function renderEditor(existing, defaultCategory) {
  const editing = Boolean(existing);
  const cancelRoute = editing ? `recipe/${existing.id}` : route.startsWith('box/') || route.startsWith('recipe/') ? route : 'home';
  const draftPhotos = [...(existing?.photos ?? [])];
  editor.innerHTML = `
    <div class="editor-inner subpage">
      <button class="outline back" type="button" data-go="${cancelRoute}">Отмена</button>
      <h1 tabindex="-1" class="page-title">${editing ? 'Редактировать рецепт' : 'Создать карточку'}</h1>
      <div class="editor-layout">
      <form class="sheet">
        <label>Коробочка<select name="category" required>${categories.map(category =>
          `<option value="${category.id}" ${category.id === (existing?.category ?? defaultCategory) ? 'selected' : ''}>${escapeHtml(category.name)}</option>`).join('')}</select></label>
        <label>Название блюда<input name="title" maxlength="90" required value="${escapeHtml(existing?.title ?? '')}"></label>
        <label>На сколько порций рецепт<input name="servings" type="number" inputmode="numeric" min="1" max="100" step="1" required value="${existing?.servings ?? 1}"></label>
        <label>Короткое описание<textarea name="short" rows="2" maxlength="170" required>${escapeHtml(existing?.short ?? '')}</textarea></label>
        <label>Полное описание<textarea name="description" rows="4" required>${escapeHtml(existing?.description ?? '')}</textarea></label>
        <label>Что это за блюдо? <span class="muted optional">Необязательно</span><textarea name="overview" rows="2" maxlength="400" placeholder="Объясни в паре фраз, на что это похоже.">${escapeHtml(existing?.overview ?? '')}</textarea></label>
        <label>Калорийность одной порции, ккал <span class="muted optional">Необязательно</span><input name="calories" type="number" inputmode="numeric" min="0" max="100000" step="1" value="${existing?.calories ?? ''}"></label>
        <fieldset>
          <legend>Фотографии</legend>
          <label>Загрузить фотографии<input type="file" name="photos" accept="image/*" multiple aria-describedby="photo-help"></label>
          <p id="photo-help" class="muted">Первая фотография станет обложкой.</p>
          <div class="photo-previews"></div>
        </fieldset>
        <fieldset>
          <legend>Ингредиенты</legend>
          <p class="muted ingredient-hint">Начинай количество с числа, например 150 г или ½ ч. л. Так сайт сможет пересчитать его для других порций.</p>
          <div class="fields ingredients-fields"></div>
          <button class="quiet" type="button" data-add="ingredient">＋ Добавить ингредиент</button>
        </fieldset>
        <fieldset>
          <legend>Шаги приготовления</legend>
          <div class="fields step-fields"></div>
          <button class="quiet" type="button" data-add="step">＋ Добавить шаг</button>
        </fieldset>
        <p class="notice" role="alert" hidden></p>
        <div class="button-row"><button class="primary" type="submit">Сохранить карточку</button></div>
      </form>
      <aside class="live-preview"><h2>Так будет выглядеть карточка</h2><div class="live-preview-card"></div></aside>
      </div>
    </div>`;
  const form = $('form', editor);
  const ingredientFields = $('.ingredients-fields', form);
  const stepFields = $('.step-fields', form);
  const photoInput = form.elements.photos;
  const previews = $('.photo-previews', form);
  const notice = $('.notice', form);
  const submit = $('[type=submit]', form);
  let pendingUploads = 0;

  function updateCardPreview() {
    const { title, short, servings, calories, category } = form.elements;
    $('.live-preview-card', editor).innerHTML = recipeCard({
      id: 'preview', title: title.value.trim() || 'Название блюда', short: short.value.trim() || 'Короткое описание',
      photos: draftPhotos, ingredients: [], category: category.value, servings: Number(servings.value),
      calories: calories.value === '' ? null : Number(calories.value),
    }, true, null, true);
  }
  for (const field of ['title', 'short', 'servings', 'calories', 'category']) {
    form.elements[field].addEventListener('input', updateCardPreview);
  }

  function message(text = '') {
    notice.hidden = !text;
    notice.textContent = text;
  }

  function renderPhotos() {
    previews.innerHTML = draftPhotos.map((photo, index) => `
      <div class="photo-preview">
        <img src="${escapeHtml(photoUrl(photo))}" alt="${index === 0 ? 'Обложка' : `Фото ${index + 1}`}">
        <button class="remove" type="button" data-photo="${index}" aria-label="Убрать фото ${index + 1}">Убрать</button>
      </div>`).join('');
    updateCardPreview();
  }

  function updateRows(container) {
    [...container.children].forEach((row, i, rows) => {
      const remove = $('button', row);
      remove.hidden = rows.length === 1;
      const index = i + 1;
      if (container === stepFields) {
        $('.step-number', row).textContent = `Шаг ${index}`;
        remove.setAttribute('aria-label', `Убрать шаг ${index}`);
      } else {
        remove.setAttribute('aria-label', `Убрать ингредиент ${index}`);
      }
    });
  }

  function addRow(kind, value, focus = false) {
    const ingredient = kind === 'ingredient';
    const container = ingredient ? ingredientFields : stepFields;
    const row = document.createElement('div');
    row.className = ingredient ? 'ingredient-row' : 'step-row';
    row.innerHTML = ingredient
      ? `<label>Ингредиент<input name="ingredient" required value="${escapeHtml(value?.[0] ?? '')}"></label>
         <label>Количество<input name="amount" required value="${escapeHtml(value?.[1] ?? '')}"></label>`
      : `<label><span class="step-number"></span><textarea name="step" rows="2" required>${escapeHtml(value ?? '')}</textarea></label>`;
    const remove = document.createElement('button');
    remove.className = 'remove';
    remove.type = 'button';
    remove.textContent = '×';
    remove.addEventListener('click', () => {
      const sibling = row.nextElementSibling ?? row.previousElementSibling;
      row.remove();
      updateRows(container);
      $('input, textarea', sibling)?.focus();
    });
    row.append(remove);
    container.append(row);
    updateRows(container);
    if (focus) $('input, textarea', row).focus();
  }

  for (const ingredient of existing?.ingredients ?? [null]) addRow('ingredient', ingredient);
  for (const step of existing?.steps ?? [null]) addRow('step', step);
  renderPhotos();

  for (const add of $$('[data-add]', form)) add.addEventListener('click', () => addRow(add.dataset.add, null, true));
  previews.addEventListener('click', event => {
    const button = event.target.closest('[data-photo]');
    if (!button) return;
    draftPhotos.splice(Number(button.dataset.photo), 1);
    renderPhotos();
    photoInput.focus();
  });
  photoInput.addEventListener('change', async () => {
    const files = [...photoInput.files];
    photoInput.value = '';
    if (!files.length) return;
    pendingUploads += 1;
    photoInput.disabled = true;
    submit.disabled = true;
    message();
    try {
      const results = await Promise.allSettled(files.map(async file => {
        const image = new Image();
        const url = URL.createObjectURL(file);
        try {
          image.src = url;
          await image.decode();
          return file;
        } finally {
          URL.revokeObjectURL(url);
        }
      }));
      draftPhotos.push(...results.filter(result => result.status === 'fulfilled').map(result => result.value));
      renderPhotos();
      if (results.some(result => result.status === 'rejected')) message('Некоторые файлы не удалось открыть. Попробуй фото в формате JPG, PNG или WebP.');
    } finally {
      pendingUploads -= 1;
      photoInput.disabled = false;
      submit.disabled = pendingUploads > 0;
    }
  });
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (submit.disabled) return;
    message();
    const emptyField = $$('input[required], textarea[required]', form).find(input => !input.value.trim());
    if (emptyField) {
      message('Заполни это поле.');
      emptyField.focus();
      return;
    }
    if (!draftPhotos.length) {
      message('Добавь хотя бы одну фотографию.');
      photoInput.focus();
      return;
    }
    if (!storage) {
      message('Хранилище недоступно. Открой сайт в обычном окне браузера и попробуй снова.');
      return;
    }
    const data = new FormData(form);
    const item = {
      id: existing?.id ?? `own-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`,
      category: data.get('category'),
      title: data.get('title').trim(),
      servings: Number(data.get('servings')),
      short: data.get('short').trim(),
      description: data.get('description').trim(),
      overview: data.get('overview').trim(),
      calories: data.get('calories') === '' ? null : Number(data.get('calories')),
      ingredients: data.getAll('ingredient').map((name, index) => [name.trim(), data.getAll('amount')[index].trim()]),
      steps: data.getAll('step').map(step => step.trim()),
      photos: [...draftPhotos],
    };
    submit.disabled = true;
    try {
      await saveRecord(storage, 'recipes', item);
      personal.set(item.id, item);
      if (item.servings !== existing?.servings) servingChoices.delete(item.id);
      if (!editor.contains(form) || editor.hidden) return;
      go('box/' + item.category, { replace: true });
      const card = $$('[data-go]', collection).find(button => button.dataset.go === 'recipe/' + item.id);
      card.focus();
      card.scrollIntoView({ block: 'nearest' });
      announcement.textContent = editing ? 'Изменения сохранены.' : 'Карточка добавлена.';
    } catch {
      message('Не удалось сохранить рецепт. Попробуй выбрать фотографии меньшего размера.');
      submit.disabled = false;
    }
  });
}

async function init() {
  try {
    storage = await connectStorage();
    const [boxes, recipes] = await Promise.all([readRecords(storage, 'boxes'), readRecords(storage, 'recipes')]);
    categories.push(...boxes);
    for (const item of recipes) personal.set(item.id, item);
  } catch {
    storage = null;
  }
  history.scrollRestoration = 'manual';
  setPreference('theme', preference('theme') === 'evening' ? 'evening' : 'morning');
  setPreference('catalog', preference('catalog') === 'compact' ? 'compact' : 'grid');
  setupCardTilt();
  searchInput.addEventListener('input', renderSearch);
  $('.search-form', search).addEventListener('submit', event => event.preventDefault());
  $('#clear-search').addEventListener('click', () => {
    searchInput.value = '';
    renderSearch();
    searchInput.focus();
  });
  show(location.hash.slice(1) || 'home', { initial: true });
  window.addEventListener('popstate', () => {
    remember();
    show(location.hash.slice(1) || 'home', { restore: true });
  });
  document.addEventListener('click', event => {
    const layout = event.target.closest('[data-layout]');
    if (layout) {
      setPreference('catalog', layout.dataset.layout);
      return;
    }
    if (event.target.closest('[data-theme-toggle]')) {
      setPreference('theme', document.documentElement.dataset.theme === 'evening' ? 'morning' : 'evening');
      return;
    }
    const jump = event.target.closest('[data-jump]');
    if (jump) {
      const heading = document.getElementById(jump.dataset.jump);
      event.preventDefault();
      heading.focus({ preventScroll: true });
      heading.scrollIntoView({ block: 'start' });
      return;
    }
    const category = event.target.closest('[data-category]');
    if (category) {
      openGift(category);
      return;
    }
    const create = event.target.closest('.create');
    if (create) {
      if (route === 'new' || route.startsWith('new/')) $('form [name=title]', editor).focus();
      else go(route.startsWith('box/') ? 'new/' + route.split('/')[1] : 'new');
      return;
    }
    const target = event.target.closest('[data-go], a[href^="#"]');
    if (!target || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    const next = target.dataset.go ?? target.hash.slice(1);
    const backFromBox = next === 'home' && target.classList.contains('back') && route.startsWith('box/');
    if (backFromBox) {
      closeGift(route.split('/')[1]);
      return;
    }
    const fromCard = target.classList.contains('recipe-card');
    const toCards = target.classList.contains('back') && route.startsWith('recipe/') && (next.startsWith('box/') || next === 'search');
    const visual = fromCard
      ? { cover: snapshotCover($('img', target)) }
      : toCards ? { cover: snapshotCover($('.gallery img', detail)), recipeRoute: route } : undefined;
    if (fromCard) target.focus({ preventScroll: true });
    go(next, { restore: target.classList.contains('back'), visual });
  });
}

init();
