const friendlyTitles = {
  parfait: 'Йогурт с клубникой слоями',
  brownie: 'Шоколадный пирог квадратиками',
  'peach-apple-crisp': 'Персики и яблоки под хрустящей крошкой',
  'black-bean-and-sweet-potato-quesadillas': 'Лепёшка с бататом, фасолью и сыром',
  'farmers-market-gazpacho': 'Холодный томатный суп',
  'minestrone-soup': 'Итальянский суп с овощами и пастой',
  hummus: 'Намазка из нута',
};

const wrappingOptions = [['plain', 'Однотонная'], ['stripe', 'Полоски'], ['dots', 'Горошек']];
const boxLooks = {
  breakfast: ['rays', 'tall', '☀✦'],
  main: ['stripe', 'square', '✧✦'],
  dessert: ['confetti', 'round', '✧✦'],
  soup: ['steam', 'round', '∿'],
  salad: ['leaves', 'square', '✿'],
  snack: ['dots', 'flat', '✧✦'],
  baking: ['stripe', 'tall', '✧✦'],
  fish: ['steam', 'flat', '∿✧'],
  vegetarian: ['leaves', 'round', '✿✧'],
};

function preference(key) {
  try { return localStorage.getItem('vkusnye-' + key); }
  catch { return null; }
}

function setPreference(key, value) {
  try { localStorage.setItem('vkusnye-' + key, value); }
  catch { /* The current tab can still apply the choice. */ }
  document.documentElement.dataset[key] = value;
  if (key === 'catalog') {
    $$('[data-layout]').forEach(button => button.setAttribute('aria-pressed', String(button.dataset.layout === value)));
  } else {
    const button = $('[data-theme-toggle]');
    button.setAttribute('aria-pressed', String(value === 'evening'));
    $('.theme-label', button).textContent = value === 'evening' ? 'Утренняя кухня' : 'Вечерняя кухня';
  }
}

function catalogToggle() {
  const current = document.documentElement.dataset.catalog;
  return `<div class="catalog-switch" role="group" aria-label="Вид каталога">
    <button type="button" data-layout="grid" aria-pressed="${current !== 'compact'}">Карточки</button>
    <button type="button" data-layout="compact" aria-pressed="${current === 'compact'}">Список</button>
  </div>`;
}

function markedText(value, expression, className = '') {
  if (!expression) return escapeHtml(value);
  let end = 0;
  let output = '';
  for (const match of value.matchAll(expression)) {
    const style = className === 'cook-note' && /[×xх]/iu.test(match[0]) && /см$/iu.test(match[0])
      ? 'cook-note measure-pan' : className;
    output += escapeHtml(value.slice(end, match.index)) +
      `<mark${style ? ` class="${style}"` : ''}>${escapeHtml(match[0])}</mark>`;
    end = match.index + match[0].length;
  }
  return output + escapeHtml(value.slice(end));
}

function stepMarkup(step) {
  return markedText(step, /\d+(?:\s*[–-]\s*\d+)?\s*(?:°[CС]|минут(?:ы|у)?|мин\.|час(?:а|ов)?)(?![а-яё])|\d+\s*[×xх]\s*\d+\s*см|до (?:золотист[^,.!?;]*|мягкости[^,.!?;]*|готовности[^,.!?;]*|однородности[^,.!?;]*)|(?:должн[аоы]?|готов[аоы]?, когда) [^,.!?;]*/giu, 'cook-note');
}

function amountMarkup(amount) {
  const fraction = amount.match(/^\d*\s*([¼½¾])|^\d+[.,](25|5|75)\s/u);
  const fill = { '¼': '25%', '½': '50%', '¾': '75%', 25: '25%', 5: '50%', 75: '75%' };
  const spoon = fraction && /(?:ч|ст)\.\s*л\./u.test(amount)
    ? `<span class="measure-icon spoon" style="--spoon-fill:${fill[fraction[1] || fraction[2]]}" aria-hidden="true"></span>` : '';
  return spoon + escapeHtml(amount);
}

function setupCooking(item, view) {
  const progress = $('.prep-progress progress', view);
  const countLabel = $('.prep-progress output', view);
  const ingredients = $$('.ingredient-option input', view);
  $('.ingredients', view).addEventListener('change', () => {
    const count = ingredients.filter(input => input.checked).length;
    progress.value = count;
    countLabel.textContent = `Подготовлено ${count} из ${ingredients.length}`;
  });

  const dialog = $('.cook-mode', view);
  let step = 0;
  const current = $('.cook-step', dialog);
  const counter = $('.cook-counter', dialog);
  const previous = $('[data-cook-prev]', dialog);
  const next = $('[data-cook-next]', dialog);
  function showStep() {
    current.innerHTML = stepMarkup(item.steps[step]);
    counter.textContent = `Шаг ${step + 1} из ${item.steps.length}`;
    previous.disabled = step === 0;
    next.textContent = step === item.steps.length - 1 ? 'Завершить' : 'Дальше';
  }
  $$('[data-cook-open]', view).forEach(button => button.addEventListener('click', () => {
    showStep();
    dialog.showModal();
  }));
  previous.addEventListener('click', () => {
    step--;
    showStep();
    if (previous.disabled) next.focus();
  });
  next.addEventListener('click', () => {
    if (step === item.steps.length - 1) {
      step = 0;
      dialog.close();
    } else {
      step++;
      showStep();
    }
  });
}
