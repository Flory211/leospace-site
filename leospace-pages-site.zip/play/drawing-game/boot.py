#<!--

print("""
Loading Генератор Узоров from drawing-game.apk
    Pygbag Version : 0.9.3
    Template Version : 0.9.3
    Python  : 3.13
    CDN URL : https://pygame-web.github.io/cdn/0.9.3/
    Screen  : 1400x1200
    Title   : Генератор Узоров
    Folder  : drawing-game
    Authors : pgw
    SPDX-License-Identifier: cookiecutter.spdx

""")

import sys
import asyncio
import platform
import json
from pathlib import Path

# do not rename
async def custom_site():
    import embed
    # Keep the host page theme intact.

    platform.window.transfer.hidden = true
    platform.window.canvas.style.visibility = "visible"


    from aio.pep0723 import Config
    root = str(platform.window.leolabGameRoot or str(platform.window.location.href).split('#')[0].split('?')[0].rsplit('/', 1)[0] + '/')
    Config.PKG_INDEXES = [root + 'runtime/']
    bundle = "drawing-game"

    # the C or js loader could do that but be explicit.
    appdir = Path(f"/data/data/{bundle}") # /data/data/drawing-game
    appdir.mkdir()


    # unpack filesystem from compressed archive into work dir
    if platform.window.location.host.find('.itch.zone')>0:
        import zipfile
        async with platform.fopen("drawing-game.apk", "rb") as archive:
            with zipfile.ZipFile(archive) as zip_ref:
                zip_ref.extractall(appdir.as_posix())
    else:
        import tarfile
        async with platform.fopen(root + "drawing-game.bin", "rb") as archive:
            tar = tarfile.open(fileobj=archive, mode="r:gz")
            tar.extractall(path=appdir.as_posix(), filter='tar')
            tar.close()

    # preloader will change to work dir and prepend it to sys.path
    platform.run_main(PyConfig, loaderhome= appdir / "assets", loadermain=None)


    # wait preloading complete : that includes images and wasm compilation of bundled modules
    while embed.counter()<0:
        await asyncio.sleep(.1)

    main = appdir / "assets" / "main.py"

    # TODO: test for window.webkitAudioContext and block aio loop until gesture if accessing media manager play
    # before a gesture is recorded ( touch or click )

    # test/wait user media interaction
    if not platform.window.MM.UME:

        # now that apk is mounted we have access to font cache
        # but we need to fill __file__ that is not yet set
        __import__(__name__).__file__ = main

        # now make a prompt
        msg  = "Нажми на игру для продолжения"
        platform.window.infobox.innerText = msg
        print("\n"*4, f"    * Waiting for media user engagement. {msg} *" , "\n"*4)

        while not platform.window.MM.UME:
            await asyncio.sleep(.1)

    # start async top level machinery if not started and add a console in any case if requested.
    await TopLevel_async_handler.start_toplevel(platform.shell, console=window.python.config.debug)

    # now that apk is mounted we have access to font cache
    # but we need to fill __file__/__name__ that are not yet set
    __import__(__name__).__file__ = main


    def ui_callback(pkg):
        platform.window.infobox.innerText = "Загружаем игру…"

    await shell.source(main, callback=ui_callback)

    # if you don't reach that step
    # your main.py has an infinite sync loop somewhere !

    platform.window.infobox.style.display = "none"
    platform.window.config.gui_divider = 1
    platform.window.window_resize()
    print("default.tmpl: done")

    # No visible developer console in the published game.

asyncio.run( custom_site() )












