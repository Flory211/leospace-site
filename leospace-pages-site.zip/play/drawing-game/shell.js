/* Runtime settings for the bundled, user-authored experiment. */
window.leolabGameRoot = new URL('./', document.currentScript.src).href
window.config = {
  xtermjs: 0, _sdl2: 'canvas', user_canvas: 1, user_canvas_managed: 1,
  gui_divider: 1, ume_block: 0, can_close: 1, archive: 'drawing-game', gui_debug: 1,
  cdn: './runtime/0.9.3/', autorun: 0, PYBUILD: '3.13', fb_ar: 7 / 6,
  fb_width: '1400', fb_height: '1200',
}
window.leolabPaste = ''
window.leolabStorageFailed = false
function resizeGame() {
  const canvas = document.getElementById('canvas')
  if (!canvas) return
  const scale = Math.max(0.05, Math.min(innerWidth / 1400, (innerHeight - 52) / 1200))
  canvas.style.width = `${1400 * scale}px`
  canvas.style.height = `${1200 * scale}px`
  canvas.style.left = `${(innerWidth - 1400 * scale) / 2}px`
  canvas.style.top = '52px'
}
window.leolabReady = () => {
  document.body.dataset.ready = 'true'
  document.getElementById('loading').hidden = true
  document.getElementById('storage-warning').hidden = !window.leolabStorageFailed
  document.getElementById('copy-code').hidden = !JSON.parse(window.leolabGameState || '{}').code
  resizeGame()
}
window.leolabError = () => {
  document.getElementById('loading').hidden = false
  document.getElementById('infobox').textContent = 'Не удалось запустить игру. Обнови страницу или попробуй другой браузер.'
}
window.custom_onload = () => resizeGame()
window.custom_prerun = () => {}
window.custom_postrun = () => {}
window.addEventListener('resize', resizeGame)
window.addEventListener('paste', event => {
  window.leolabPaste = (event.clipboardData?.getData('text') || '').slice(0, 2000)
  event.preventDefault()
})
window.addEventListener('DOMContentLoaded', () => {
  document.getElementById('canvas').addEventListener('contextmenu', event => event.preventDefault())
  document.getElementById('fullscreen').addEventListener('click', async () => {
    if (document.fullscreenElement) await document.exitFullscreen()
    else await document.documentElement.requestFullscreen()
  })
  document.getElementById('copy-code').addEventListener('click', async event => {
    const code = JSON.parse(window.leolabGameState || '{}').code
    if (code) {
      try { await navigator.clipboard.writeText(code); event.target.textContent = 'Скопировано' }
      catch { event.target.textContent = code }
    }
  })
  resizeGame()
})
