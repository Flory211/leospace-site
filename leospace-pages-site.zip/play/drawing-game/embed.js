// Connect the original Python game to the experiment's own canvas, without a child document.
const root = new URL('./', import.meta.url).href
window.leolabEmbedded = true
window.leolabGameRoot = root
window.config = {
  xtermjs: 0, _sdl2: 'canvas', user_canvas: 1, user_canvas_managed: 1,
  gui_divider: 1, ume_block: 0, can_close: 1, archive: 'drawing-game', gui_debug: 1,
  cdn: `${root}runtime/0.9.3/`, autorun: 0, PYBUILD: '3.13', fb_ar: 7 / 6,
  fb_width: '1400', fb_height: '1200',
}
window.leolabPaste = ''
window.leolabStorageFailed = false
window.leolabReady = () => {
  document.getElementById('loading').hidden = true
  document.getElementById('storage-warning').hidden = !window.leolabStorageFailed
  document.getElementById('copy-code').hidden = !JSON.parse(window.leolabGameState || '{}').code
}
window.leolabError = () => {
  document.getElementById('loading').hidden = false
  document.getElementById('infobox').textContent = 'Не удалось загрузить генератор. Обнови страницу.'
}
window.custom_onload = () => {}
window.custom_prerun = () => {}
window.custom_postrun = () => {}
const canvas = document.getElementById('canvas')
canvas.addEventListener('contextmenu', event => event.preventDefault())
window.addEventListener('paste', event => {
  if (document.activeElement !== canvas) return
  window.leolabPaste = (event.clipboardData?.getData('text') || '').slice(0, 2000)
  event.preventDefault()
})
document.getElementById('fullscreen').addEventListener('click', async () => {
  if (document.fullscreenElement) await document.exitFullscreen()
  else await document.getElementById('drawing-workspace').requestFullscreen()
})
document.getElementById('copy-code').addEventListener('click', async event => {
  const code = JSON.parse(window.leolabGameState || '{}').code
  if (!code) return
  try { await navigator.clipboard.writeText(code); event.target.textContent = 'Скопировано' }
  catch { event.target.textContent = code }
})
async function loadRuntime() {
  const response = await fetch(`${root}boot.py`)
  if (!response.ok) throw new Error(`Game bootstrap: HTTP ${response.status}`)
  const boot = await response.text()
  await new Promise((resolve, reject) => {
    const script = document.createElement('script')
    script.src = `${root}runtime/browserfs.min.js`
    script.onload = resolve
    script.onerror = reject
    document.head.append(script)
  })
  const script = document.createElement('script')
  script.id = 'site'
  script.type = 'module'
  script.src = `${root}runtime/0.9.3/pythons.js`
  Object.assign(script.dataset, { python: 'python3.13', os: 'snd,gui', lines: '42', columns: '132' })
  script.textContent = boot
  script.onerror = window.leolabError
  document.head.append(script)
}
loadRuntime().catch(window.leolabError)
